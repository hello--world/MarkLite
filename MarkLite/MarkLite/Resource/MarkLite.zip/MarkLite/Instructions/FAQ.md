
### 1.How to rename file
> Click the file name on the navigation bar,then edit the name,end by return

![Markdown](http://i1.piimg.com/567954/423cf063996d02df.gif)

### 2.How to preview
> You can scroll right to preview;If you are using MarkLite on iPad,you can click the split button to preview realtime.

![Markdown](http://i1.piimg.com/567954/226912d76250e7b6.gif)

### 3.Why did I failed to move some files
> Check whether there is an dumplicate file at the destination folder

### 4.If you have other questions,contact me.
 Email: [cheng4741@gmail.com](mailto:cheng4741@gmail.com)
